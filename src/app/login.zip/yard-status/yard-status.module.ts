import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { YardStatusPageRoutingModule } from './yard-status-routing.module';
import { YardStatusPage } from './yard-status.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    YardStatusPageRoutingModule,
  ],
  declarations: [YardStatusPage],
})
export class YardStatusPageModule {}
