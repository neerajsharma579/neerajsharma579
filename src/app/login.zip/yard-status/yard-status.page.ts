import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { AuthenticationService } from '../auth/authentication.service';

@Component({
  selector: 'yard-status',
  templateUrl: './yard-status.page.html',
  styleUrls: ['./yard-status.page.scss'],
})
export class YardStatusPage implements OnInit {
  growerInfo: any = {};
  gYard: any;
  constructor(
    private apiService: ApiService,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit() {
    this.growerInfo = JSON.parse(
      JSON.stringify(this.authenticationService.token)
    );
    this.loadData();
  }

  loadData() {
    this.apiService.getYardStatus().subscribe((res: any) => {
      this.gYard = res.Data;
    });
  }
}
