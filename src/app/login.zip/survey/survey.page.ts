import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { AuthenticationService } from '../auth/authentication.service';

@Component({
  selector: 'grower-survey',
  templateUrl: './survey.page.html',
  styleUrls: ['./survey.page.scss'],
})
export class SurveyPage implements OnInit {
  growerInfo: any = {};
  gSurvey: any;

  constructor(
    private apiService: ApiService,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit() {
    if (this.authenticationService.token.LoginType == 'K') {
      this.growerInfo = JSON.parse(
        JSON.stringify(this.authenticationService.token)
      );
      this.loadData();
      //this.growerData();
    }
  }

  growerData() {
    if (this.authenticationService.token.LoginType == 'K') {
      this.loadData();
      return;
    }
    this.apiService
      .getGrowerInfo(this.growerInfo.Code)
      .subscribe((res: any) => {
        this.growerInfo = res.Data;
        this.loadData();
      });
  }

  loadData() {
    this.apiService.getGSurvey(this.growerInfo.Code).subscribe((res: any) => {
      this.gSurvey = res.Data;
    });
  }
}
